#!/bin/sh
mv pwn.patch /home/ctf/pwn
chmod 777 /home/ctf/pwn