#!/bin/sh
mv file1 /var/www/html/index.php
chmod 777 /var/www/html/index.php
mv file2 /home/ctf/pwn
chmod 777 /home/ctf/pwn
